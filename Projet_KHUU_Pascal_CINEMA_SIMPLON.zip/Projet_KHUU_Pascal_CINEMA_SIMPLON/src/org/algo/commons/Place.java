package org.algo.commons;

public abstract class Place {
int numeroRangee;
int numeroPlace;
String statut;
//�ne place est d�finie par son num�ro de rang�e, son num�ro de place et sa disponibilit�

public Place (int numeroRangee,int numeroPlace,String statut) {
	this.numeroRangee=numeroRangee; //de 0 � 7
	this.numeroPlace=numeroPlace; // de 1 � 72
	this.statut=statut; // OCCUPE OU LIBRE ou PROPOSE

}
public Place (int numeroRangee,int numeroPlace) {
	this.numeroRangee=numeroRangee; //de 0 � 7
	this.numeroPlace=numeroPlace; // de 1 � 72

}
public String getStatut() {
	return statut;
} 
public void setStatut(String statut) {
	this.statut = statut;
}
public int getNumeroRangee() {
	return numeroRangee;
}
public void setNumeroRangee(int numeroRangee) {
	this.numeroRangee = numeroRangee;
}
public int getNumeroPlace() {
	return numeroPlace;
}
public void setNumeroPlace(int numeroPlace) {
	this.numeroPlace = numeroPlace;
}


}
