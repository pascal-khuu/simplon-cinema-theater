package org.algo.commons;

import org.algo.enumeration.*;

public class PlaceLibre extends Place{
	
	public PlaceLibre(int numeroRangee, int numeroPlace) {
		super(numeroRangee, numeroPlace);
		this.statut=EnumStatut.LIBRE.getStatut(); //LIBRE
	}
}
