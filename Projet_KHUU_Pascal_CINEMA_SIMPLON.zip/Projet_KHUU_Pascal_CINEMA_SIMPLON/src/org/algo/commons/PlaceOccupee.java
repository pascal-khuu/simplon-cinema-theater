package org.algo.commons;

import org.algo.enumeration.EnumStatut;

public class PlaceOccupee extends Place {

	
	public PlaceOccupee(int numeroRangee, int numeroPlace) {
		super(numeroRangee, numeroPlace);
		this.statut=EnumStatut.OCCUPE.getStatut();
	}
}
