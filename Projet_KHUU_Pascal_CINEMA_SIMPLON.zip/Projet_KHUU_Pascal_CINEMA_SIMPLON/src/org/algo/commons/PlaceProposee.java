package org.algo.commons;

import org.algo.enumeration.EnumStatut;

public class PlaceProposee extends Place {
	
	public PlaceProposee(int numeroRangee, int numeroPlace) {
		super(numeroRangee, numeroPlace);
		this.statut=EnumStatut.PROPOSE.getStatut();
	}
}
