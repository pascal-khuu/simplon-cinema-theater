package org.algo.dev;
import java.util.ArrayList;
import java.util.Scanner;

import org.algo.commons.*;
import org.algo.enumeration.*;
import org.algo.interfaces.*;

public class AlgoAutres implements InterfaceAlgoAutres{
	
	@Override
	/* 1. Initialisation de toutes les places */
	public void initialialiserPlaces(ArrayList<Place> listPlaces) {
		// Parcours de la boucle de la rang�e 0 � 7
		int numCourant = 1; // num�ro de la place courante qui ira de 1 jusqu'� 72
		for (int indiceR = 0; indiceR <= 7; indiceR++) {
			// Parcours de la boucle de toutes les 9 places de chaque rang�e qui ira de 0 �
			// 8
			for (int indiceC = 0; indiceC <= 8; indiceC++) {
				// Ajout d'une place dans la liste listPlaces avec toutes places initialis�es au
				// statut LIBRE
				Place place = new PlaceLibre(indiceR, numCourant);
				listPlaces.add(place);
				numCourant++;

			}
		}
	}
	

	
	@Override
	// 2.b) Liste de toutes les places d�j� occup�es STATUT "OCCUPE" dans la rang�e
	// (utilisation de la liste placesOccupeesRangee)
	public int nbPlacesOccupeesRangee(ArrayList<Place> listPlaces, int numRangeeSouhaite,
			ArrayList<Place> placesOccupeesRangee) {
		for (int indiceLP = 0; indiceLP < listPlaces.size(); indiceLP++) {
			if (listPlaces.get(indiceLP).getNumeroRangee() == numRangeeSouhaite
					&& listPlaces.get(indiceLP) instanceof PlaceOccupee) {
				placesOccupeesRangee.add((PlaceOccupee) listPlaces.get(indiceLP));
			}

		}
		System.out.println(
				EnumAffichage.affichageNombrePlacesPrisRange.getMsgaffichage()  + numRangeeSouhaite + " : " + placesOccupeesRangee.size());
		System.out.println("");
		
		return placesOccupeesRangee.size();
	}
	
	@Override
	// 2.c) Liste de toutes les places libres STATUT LIBRE dans la rang�e
	// (utilisation de la liste placesLibresRangee)
	public void listPlacesLibresRangee(ArrayList<Place> listPlaces, int numRangeeSouhaite,
			ArrayList<Place> placesLibresRangee) {
		for (int indiceLP = 0; indiceLP < listPlaces.size(); indiceLP++) {
			if (listPlaces.get(indiceLP).getNumeroRangee() == numRangeeSouhaite
					&& listPlaces.get(indiceLP) instanceof PlaceLibre) {
				placesLibresRangee.add((PlaceLibre) listPlaces.get(indiceLP));
			}

		}
		System.out.println(
				EnumAffichage.affichageNombrePlacesLibresRange.getMsgaffichage()  + numRangeeSouhaite + " : " + placesLibresRangee.size());
		System.out.println("");

	}
	
	@Override
	/*
	 * 3) Proposition des places � r�server parmi les places disponibles de la
	 * rang�e 	 */
	public void changerStatutLibreAPropose(ArrayList<Place> listPlaces, ArrayList<Place> placesLibresRangee,
			int nbPlaceSouhaite) {
		// Modification du statut � PROPOSE des places libres au statut "LIBRE" de la
		// rangee jusqu'au
		// nombre souhaite
		for (int indiceLibP = 0; indiceLibP < nbPlaceSouhaite; indiceLibP++) {
			Place placeProposee= new PlaceProposee(placesLibresRangee.get(indiceLibP).getNumeroRangee(),
					placesLibresRangee.get(indiceLibP).getNumeroPlace());
			placesLibresRangee.remove(indiceLibP);
			placesLibresRangee.add(indiceLibP, placeProposee);
			
		}

		// Changement du statut � "PROPOSE" des places de la rang�e en fonction du
		// nombre de places s�lectionn�e
		for (int indiceLP = 0; indiceLP < listPlaces.size(); indiceLP++) {
			for (int indiceLibP = 0; indiceLibP < placesLibresRangee
					.size(); indiceLibP++) {
				if (listPlaces.get(indiceLP).getNumeroPlace() == placesLibresRangee
						.get(indiceLibP).getNumeroPlace()
						&& placesLibresRangee.get(indiceLibP) instanceof PlaceProposee) {
					Place placeProposee=new PlaceProposee(listPlaces.get(indiceLP).getNumeroRangee(),
							listPlaces.get(indiceLP).getNumeroPlace());
					listPlaces.remove(indiceLP);
					listPlaces.add(indiceLP,placeProposee);
				}
			}
		}

		System.out.println(EnumSucces.messagePlacesProposees.getMsgSuccess());
		System.out.println("");
	}

	@Override
	// 5) a) Confirmation de la r�servation: Changer le statut des places confirm�es STATUT PROPOSE au statut "OCCUPE"
	public void changerStatutProposeAOccupe(ArrayList<Place> listPlaces) {
		for (int indiceLP = 0; indiceLP < listPlaces.size(); indiceLP++) {
			if (listPlaces.get(indiceLP) instanceof PlaceProposee) {
				Place placeOccupee=new PlaceOccupee(listPlaces.get(indiceLP).getNumeroRangee(),listPlaces.get(indiceLP).getNumeroPlace());
				listPlaces.remove(indiceLP);
				listPlaces.add(indiceLP,placeOccupee);
			}
		}
		System.out.println(EnumSucces.messageReservationPriseEnCompte.getMsgSuccess());
		System.out.println("");

	}

	@Override

	// 5) b) Non confirmation de la r�servation: R�initialiser le statut des places STATUT PROPOSE
	// non confirm�es au statut "LIBRE"
	public void changerStatutProposeALibre(ArrayList<Place> listPlaces) {
		for (int indiceLP = 0; indiceLP < listPlaces.size(); indiceLP++) {
			if (listPlaces.get(indiceLP) instanceof PlaceProposee) {
				Place placeLibre=new PlaceLibre(listPlaces.get(indiceLP).getNumeroRangee(),listPlaces.get(indiceLP).getNumeroPlace());
				listPlaces.remove(indiceLP);
				listPlaces.add(indiceLP,placeLibre);
			}
		}
		System.out.println(EnumEchec.messageReservationRefusee.getMsgEchec());
		System.out.println("");


	}
	
	public String saisieConfirmation(String choixConfirmation) {
		Scanner saisieConfirmation = new Scanner(System.in);
		String reponse = "";
		System.out.println(choixConfirmation); //MESSAGE DE CONFIRMATION questionsConfirmation[]

		int estValideReponse = -1;
		while (estValideReponse==-1) {
			try {//CAS VALEUR ENTREE UN STRING
				reponse = saisieConfirmation.next();
				System.out.println("");
				if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix()) || reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) { //STRING EGAL A Y ou N
					estValideReponse = 1;
					break;
				}else { // STRING DIFFERENT DE Y OU DE N
					System.out.println(EnumQuestionConfirmation.reSaisieConfirmation.getMsgQuestion());
					saisieConfirmation.nextLine();
				}
			} catch (Exception e) { //VALEUR DIFFERENTE D'UN STRING
				System.out.println(EnumQuestionConfirmation.reSaisieConfirmation.getMsgQuestion());
				saisieConfirmation.nextLine();
			}
		}
		return reponse;
	}
	
}
