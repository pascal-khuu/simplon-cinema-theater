package org.algo.dev;

import java.util.ArrayList;
import java.util.Scanner;

import org.algo.commons.*;
import org.algo.interfaces.*;
import org.algo.enumeration.*;

public class AlgoSaisieReservation extends AlgoAutres implements InterfaceAlgoSaisieReservation{
	
	@Override
	/*
	 * 2. Reserver des places : a) choix du nombre de places et de la rang�e,
	 * b)v�rifier places disponibles dans la rang�e souhait�e
	 */
	public void reserverPlaces(ArrayList<Place> listPlaces) {
		// a) Choix de l'utilisateur sur le nombre de places (1 � 9)
		ArrayList<Place> placesOccupeesRangee = new ArrayList<Place>();
		ArrayList<Place> placesLibresRangee = new ArrayList<Place>();
		int nbPlaceSouhaite = saisieNbPlaceSouhaite();
		int numRangeeSouhaite = saisieNumRangeeSouhaitee();
		// b) Nombre de places occup�es dans la rang�e
		int nbPlacesOccupes=nbPlacesOccupeesRangee(listPlaces, numRangeeSouhaite, placesOccupeesRangee);
		// c) Liste de toutes les places libres dans la rang�e
		listPlacesLibresRangee(listPlaces, numRangeeSouhaite, placesLibresRangee);
		// d) V�rifier les places disponibles dans la rang�e : afficher la
		// repr�sentation sinon message d'erreur
		verifierPlacesDisponibles(nbPlaceSouhaite, nbPlacesOccupes, listPlaces, placesLibresRangee);
	}
	// 2)a : Saisie du nombre de places souhait�es (tant que le chiffre est ins�r� n'est pas un entier et n'est pas compris entre 1 et 9, boucle (tant que la valeur estValie �-1))
		@Override
		public int saisieNbPlaceSouhaite() {
			Scanner saisieNbPlace = new Scanner(System.in);
			int nbPlaceSouhaite = 0;
			System.out.println(EnumSaisie.saisieNombrePlaces.getMsgSaisie());
			int estValideNbPlace= -1;
			while (estValideNbPlace==-1) { //SAISIE d'UN ENTIER
				try {
					nbPlaceSouhaite = saisieNbPlace.nextInt();
					System.out.println("");
					if (nbPlaceSouhaite >=1 && nbPlaceSouhaite < 10) { //VALEUR COMPRISE ENTRE 1 et 9
						estValideNbPlace = 1;
						break;
					}else { //VALEUR PAS DANS LES BORNES 1 et 9
						estValideNbPlace = -1;
						System.out.println(EnumSaisie.reSaisieNombrePlaces.getMsgSaisie());
						saisieNbPlace.nextLine();
					}
				} catch (Exception e) { //SAISIE AUTRE QU'UN ENTIER
					estValideNbPlace = -1;
					System.out.println(EnumSaisie.reSaisieNombrePlaces.getMsgSaisie());
					saisieNbPlace.nextLine();
					
				}
			}

			return nbPlaceSouhaite;

		}

		// 2)a : Saisie du num�ro de rang�e (tant que le chiffre est ins�r� n'est pas un entier et n'est pas compris entre 0 et 7 => boucle (tant que la valeur est �gale �-1))
		@Override
		public int saisieNumRangeeSouhaitee() {
			Scanner saisieRangee = new Scanner(System.in);
			int numRangeeSouhaite = 0;
			System.out.println(EnumSaisie.saisieRangeePlaces.getMsgSaisie());
			int estValideRangee = -1;
			while (estValideRangee==-1) { //SAISIE d'UN ENTIER
				try {
					numRangeeSouhaite = saisieRangee.nextInt();
					System.out.println("");
					if (numRangeeSouhaite >=0 && numRangeeSouhaite < 8) { //VALEUR COMPRISE ENTRE 0 et 7
						estValideRangee = 1;
						break;
					}else { //VALEUR PAS DANS LES BORNES (0 et 7)
						estValideRangee = -1;
						System.out.println(EnumSaisie.reSaisieRangeePlaces.getMsgSaisie());
						saisieRangee.nextLine();
					}
				} catch (Exception e) { //SAISIE AUTRE QU'UN ENTIER
					estValideRangee = -1;
					System.out.println(EnumSaisie.reSaisieRangeePlaces.getMsgSaisie());
					saisieRangee.nextLine();
				}
			}
			return numRangeeSouhaite;
		}
		
		
		@Override
		// 2.d) V�rifier les places disponibles dans la rang�e : afficher la
		// repr�sentation de la salle � l'utilisateur sinon message d'erreur
		public void verifierPlacesDisponibles(int nbPlaceSouhaite, int nbPlacesOccupes,
				ArrayList<Place> listPlaces, ArrayList<Place> placesLibresRangee) {
			String reponse="";
			// 1er cas: PLUS DE PLACES: cas o� le nombre de places occup�es est identique au nombre maximum de la rang�e
			if (9 - nbPlacesOccupes == 0) { 
				reponse=saisieConfirmation(EnumQuestionConfirmation.messageErreurEtSaisiePlusDePlaces.getMsgQuestion());
				if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix())) { // YES
					reserverPlaces(listPlaces);
				} else if (reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) { // NO
					System.out.println(EnumEchec.messageAbandon.getMsgEchec());
					System.exit(-1);
				}
		// 2eme cas: PAS ASSEZ DE PLACES
			} else if (9 - nbPlacesOccupes- nbPlaceSouhaite < 0) {
				reponse=saisieConfirmation(EnumQuestionConfirmation.messageErreurEtSaisiePasAssezPlaces.getMsgQuestion());
				if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix())) { // YES
					reserverPlaces(listPlaces);
				} else if (reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) { // NO
					System.out.println(EnumEchec.messageAbandon.getMsgEchec());
					System.exit(-1);
				}
		// 3�me cas: PLACES DISPONIBLES DANS LA RANGEE
			} else {
	// 3) Proposition des places � r�server parmi les places disponibles de la rang�e
				changerStatutLibreAPropose(listPlaces, placesLibresRangee, nbPlaceSouhaite);
	// 4) Affichage de la repr�sentation de la salle
				afficherPlaces(listPlaces);
	// 5) Confirmer la r�servation Y ou N ?
				confirmerReservation(listPlaces);
			}

		}
		
		@Override
		/* 4) Affichage de la repr�sentation de la salle */
		public void afficherPlaces(ArrayList<Place> listPlaces) {
			int valeurCurseur = 0; // D�claration de valeur curseur pour comparer avec le num�ro de la rang�e qui
			// ira de 0 � 7
			// Parcours de chaque indice de chaque �l�ment de l'arraylist listPlaces
			System.out.println(EnumAffichage.affichageSalle.getMsgaffichage() );
			System.out.print(0 + " ");
			for (int indiceLP = 0; indiceLP <= listPlaces.size() - 1; indiceLP++) {
				/*
				 * Si la valeur curseur est diff�rente du num�ro de rang�e de l'�l�ment de
				 * l'arraylist => Retour � la ligne et valeur curseur = valeur de la nouvelle
				 * rang�e
				 */
				if (listPlaces.get(indiceLP).getNumeroRangee() != valeurCurseur) {
					System.out.println("");
					valeurCurseur++;
					System.out.print(valeurCurseur + " ");
				}
				// Si la place est libre : "-"
				if (listPlaces.get(indiceLP) instanceof PlaceLibre)
					System.out.print(EnumSymbole.LIBRE.getSymbole());
				// si la place est d�j� occup�e : "/"
				else if (listPlaces.get(indiceLP) instanceof PlaceOccupee) {
					System.out.print(EnumSymbole.OCCUPE.getSymbole());
				} else { // si la place est propos�e pour �tre confirm�e : "X"
					System.out.print(EnumSymbole.PROPOSE.getSymbole());

				}
			}
			System.out.println("");

		}

		@Override
		/* 5) Confirmation la r�servation des places */
		public void confirmerReservation(ArrayList<Place> listPLaces) {
			String reponse="";
			
			reponse=saisieConfirmation(EnumQuestionConfirmation.saisieConfirmationReservation.getMsgQuestion());
			// 5) a) Confirmation de la r�servation: Changer le statut des places confirm�es
			// au statut "OCCUPE" et afficher la salle
			if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix())) {
				changerStatutProposeAOccupe(listPLaces);
				afficherPlaces(listPLaces);
				// Reproposer
				reponse=saisieConfirmation(EnumQuestionConfirmation.saisieRefaireReservation.getMsgQuestion());
				if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix())) { // YES
					reserverPlaces(listPLaces);
				} else if (reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) {
					System.out.println(EnumEchec.messageAbandon.getMsgEchec());
					System.exit(-1);
				}
				// 5) b) Non confirmation de la r�servation: R�initialiser le statut des places
				// non confirm�es au statut "LIBRE"
			} else if (reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) {
				changerStatutProposeALibre(listPLaces);
				// Reproposer
				reponse=saisieConfirmation(EnumQuestionConfirmation.saisieRecommencer.getMsgQuestion());
				if (reponse.equals(EnumReponseConfirmation.YES.getMsgChoix())) {
					reserverPlaces(listPLaces);
				} else if (reponse.equals(EnumReponseConfirmation.NO.getMsgChoix())) {
					System.out.println(EnumEchec.messageAbandon.getMsgEchec());
					System.exit(-1);
				}
			}

		}
}
