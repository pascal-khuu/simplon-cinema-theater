package org.algo.enumeration;

public enum EnumAffichage {
	affichageSalle("Affichage de la salle :"),
	affichageNombrePlacesPrisRange("Nombre de places occup�es pour la rang�e num�ro "),
	affichageNombrePlacesLibresRange("Nombre de places libres pour la rang�e num�ro ");

	String msgaffichage;
	EnumAffichage(String msgaffichage) {
		this.msgaffichage=msgaffichage;
	}
	public String getMsgaffichage() {
		return msgaffichage;
	}
	public void setMsgaffichage(String msgaffichage) {
		this.msgaffichage = msgaffichage;
	}
	
	
}
