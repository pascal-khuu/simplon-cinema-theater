package org.algo.enumeration;

public enum EnumEchec {
	messageReservationRefusee("Votre r�servation n'a pas �t� prise en compte!!"),
	messageAbandon("Votre op�ration a �t� abandonn�e!!");

	String msgEchec;
	EnumEchec(String msgEchec) {
		this.msgEchec=msgEchec;
	}
	public String getMsgEchec() {
		return msgEchec;
	}
	public void setMsgEchec(String msgEchec) {
		this.msgEchec = msgEchec;
	}
	
	

}
