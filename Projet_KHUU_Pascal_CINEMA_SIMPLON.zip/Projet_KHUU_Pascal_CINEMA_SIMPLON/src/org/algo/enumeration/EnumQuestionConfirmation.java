package org.algo.enumeration;


public enum EnumQuestionConfirmation {

	messageErreurEtSaisiePlusDePlaces("Il n'y a plus de places!!! Voulez-vous recommencer(Y/N) ? "),
	messageErreurEtSaisiePasAssezPlaces("Il n'y a pas assez de places!!! Voulez-vous recommencer(Y/N) ?"),
	saisieConfirmationReservation("Voulez-vous confirmer votre r�servation (Y/N) ?"),
	saisieRefaireReservation("Voulez-vous refaire une r�servation (Y/N) ?"),
	saisieRecommencer("Voulez-vous recommencer (Y/N) ?"),
	reSaisieConfirmation("La valeur saisie est invalide. Veuillez redonner votre r�ponse (entrez soit 'Y' ou 'N') : ");
	
	String msgQuestion;

	EnumQuestionConfirmation(String msgQuestion) {
		this.msgQuestion = msgQuestion;
	}

	public String getMsgQuestion() {
		return msgQuestion;
	}

	public void setMsgQuestion(String msgQuestion) {
		this.msgQuestion = msgQuestion;
	}


	
	
}
