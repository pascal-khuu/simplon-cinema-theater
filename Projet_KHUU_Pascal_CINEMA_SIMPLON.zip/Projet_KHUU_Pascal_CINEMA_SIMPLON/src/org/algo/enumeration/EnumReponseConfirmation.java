package org.algo.enumeration;

public enum EnumReponseConfirmation {

	YES("Y"), NO("N");

	public String msgChoix;

	EnumReponseConfirmation(String msgChoix) {
		this.msgChoix = msgChoix;
	}


	public String getMsgChoix() {
		return msgChoix;
	}

	public void setMsgChoix(String msgChoix) {
		this.msgChoix = msgChoix;
	}

}
