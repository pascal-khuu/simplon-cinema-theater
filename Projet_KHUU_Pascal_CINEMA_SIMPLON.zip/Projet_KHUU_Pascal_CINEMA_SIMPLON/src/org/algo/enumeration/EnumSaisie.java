package org.algo.enumeration;

public enum EnumSaisie {

	saisieNombrePlaces("Veuillez saisir le nombre de places choisies (entre 1 et 9) : "),
	reSaisieNombrePlaces("La valeur saisie est invalide. Veuillez ressaisir le nombre de places choisies : "),
	saisieRangeePlaces("Veuillez saisir la rang�e de places (entre 0 et 7) : "),
	reSaisieRangeePlaces("La valeur saisie est invalide. Veuillez ressaisir la rang�e de places : ");

	String msgSaisie;

	EnumSaisie(String msgSaisie) {
		this.msgSaisie = msgSaisie;
	}

	public String getMsgSaisie() {
		return msgSaisie;
	}

	public void setMsgSaisie(String msgSaisie) {
		this.msgSaisie = msgSaisie;
	}


}
