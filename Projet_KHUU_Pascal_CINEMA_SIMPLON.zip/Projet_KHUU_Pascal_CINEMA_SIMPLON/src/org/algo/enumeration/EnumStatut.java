package org.algo.enumeration;

public enum EnumStatut {

	LIBRE("LIBRE"), OCCUPE("OCCUPE"), PROPOSE("PROPOSE");

	public String statut;

	EnumStatut(String statut) {
		this.statut = statut;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	
}
