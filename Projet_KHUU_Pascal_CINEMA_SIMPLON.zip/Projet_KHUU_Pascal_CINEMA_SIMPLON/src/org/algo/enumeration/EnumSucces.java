package org.algo.enumeration;

public enum EnumSucces {
	messageReservationPriseEnCompte("Votre r�servation a �t� prise en compte!! "),
	messagePlacesProposees("Proposition des places....");

	String msgSuccess;
	EnumSucces(String msgSuccess) {
		this.msgSuccess=msgSuccess;
	}
	public String getMsgSuccess() {
		return msgSuccess;
	}
	public void setMsgSuccess(String msgSuccess) {
		this.msgSuccess = msgSuccess;
	}
	
	

}