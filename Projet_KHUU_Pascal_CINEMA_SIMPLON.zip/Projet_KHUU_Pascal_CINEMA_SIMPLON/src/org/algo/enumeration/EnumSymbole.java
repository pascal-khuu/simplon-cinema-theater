package org.algo.enumeration;

public enum EnumSymbole {
	LIBRE(" - "), OCCUPE(" / "), PROPOSE(" X ");

	String symbole;

	EnumSymbole(String symbole) {
		this.symbole = symbole;
	}

	public String getSymbole() {
		return symbole;
	}

	public void setSymbole(String symbole) {
		this.symbole = symbole;
	}

}
