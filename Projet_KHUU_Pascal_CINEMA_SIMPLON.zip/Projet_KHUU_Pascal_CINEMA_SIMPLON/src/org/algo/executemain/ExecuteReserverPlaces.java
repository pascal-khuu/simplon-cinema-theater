package org.algo.executemain;
import java.util.ArrayList;

import org.algo.commons.*;
import org.algo.dev.*;


public class ExecuteReserverPlaces {

	public static void main(String[] args) {
		AlgoSaisieReservation algo=new AlgoSaisieReservation();
		ArrayList<Place> listPlaces = new ArrayList<Place>(); // Initialisation d'une arraylist contenant toutes les  places
		algo.initialialiserPlaces(listPlaces); // 1.Initialisation de toutes les places
		algo.reserverPlaces(listPlaces); // 2. R�server des places

	}

}