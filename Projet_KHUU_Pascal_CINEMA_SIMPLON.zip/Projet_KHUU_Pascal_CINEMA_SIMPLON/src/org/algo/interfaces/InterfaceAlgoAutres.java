package org.algo.interfaces;
import java.util.ArrayList;

import org.algo.commons.*;

public interface InterfaceAlgoAutres {
	/* 1. Initialisation de toutes les places au statut libre */
	public void initialialiserPlaces(ArrayList<Place> listPlaces);

	/* 2.b) Liste de toutes les places d�j� occup�es dans la rang�e (utilisation de la liste placesOccupeesRangee)*/
	public int nbPlacesOccupeesRangee(ArrayList<Place> listPlaces, int numRangeeSouhaite,
			ArrayList<Place> placesOccupeesRangee);
	/*2.c) Liste de toutes les places libres dans la rang�e (utilisation de la liste placesLibresRangee) */
	public void listPlacesLibresRangee(ArrayList<Place> listPlaces, int numRangeeSouhaite,
			ArrayList<Place> placesLibresRangee);

	/* 3) Proposition des places � r�server au STATUT PROPOSED parmi les places disponibles de la rang�e au STATUT LIBRE */
	public void changerStatutLibreAPropose(ArrayList<Place> listPlaces, ArrayList<Place> placesLibresRangee,
			int nbPlaceSouhaite);
	/* 5) a) Confirmation de la r�servation: Changer le statut des places confirm�es au statut "PRIS"*/
	public void changerStatutProposeAOccupe(ArrayList<Place> listPLaces);
	/* 5) b) Non confirmation de la r�servation: R�initialiser le statut des places non confirm�es au statut "LIBRE"*/
	public void changerStatutProposeALibre(ArrayList<Place> listPLaces);
	
	/*6) V�rifie que la r�ponse � la question de confirmation est correcte*/
	public String saisieConfirmation(String choixConfirmation);
}
