package org.algo.interfaces;
import java.util.ArrayList;

import org.algo.commons.*;

public interface InterfaceAlgoSaisieReservation {

	/*2. Reserver des places : a) choix du nombre de places et de la rang�e, b)v�rifier places disponibles dans la rang�e souhait�e	 */
	public void reserverPlaces(ArrayList<Place> listPlaces);
	
	// 2)a : Saisie du nombre de places souhait�es
	public int saisieNbPlaceSouhaite();
	
	// 2)a : Saisie du num�ro de rang�e
	public int saisieNumRangeeSouhaitee();

	
	/* 2.d) V�rifier les places disponibles dans la rang�e : afficher la repr�sentation sinon message d'erreur */
	public void verifierPlacesDisponibles(int nbPlaceSouhaite, int nbPlacesOccupes,
			ArrayList<Place> listPlaces, ArrayList<Place> placesLibresRangee);
	/* 3) Proposition des places � r�server au STATUT PROPOSED parmi les places disponibles de la rang�e au STATUT LIBRE */

	public void afficherPlaces(ArrayList<Place> listPlaces);
	/* 5) Confirmation la r�servation des places */
	public void confirmerReservation(ArrayList<Place> listPLaces);
	/* 5) a) Confirmation de la r�servation: Changer le statut des places confirm�es au statut "PRIS"*/

	
}
